#import <GHUnit/GHUnit.h>

@interface _Template_Test : GHTestCase {
}

@end

@implementation _Template_Test

- (void) setUp {
}

- (void) testExample {
	GHAssertTrue(true, nil);
}

@end
