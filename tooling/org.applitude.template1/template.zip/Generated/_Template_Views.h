#import "_Template_ViewController.h"

@interface _Template_Views : NSObject {
}

+ (_Template_ViewController *) create_Template_;


@end
