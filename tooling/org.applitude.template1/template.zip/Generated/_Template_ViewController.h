#import "BoxTableViewController.h"

@interface _Template_ViewController : BoxTableViewController {
}

- (id) init;

@end
