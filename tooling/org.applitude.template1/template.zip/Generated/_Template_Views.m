#import "_Template_Views.h"

@implementation _Template_Views

+ (_Template_ViewController *) create_Template_ {
	return [[[_Template_ViewController alloc] init] autorelease];
}

@end
