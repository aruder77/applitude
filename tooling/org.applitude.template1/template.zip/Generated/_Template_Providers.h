
@interface _Template_Providers : NSObject {
}

+ (_Template_Providers *) sharedProviders;



@end
